// Note : created date for 'first' and 'seconde' users are different than created date on given users array.
let users = [{
    id: "123456789",
    createdDate: "2021-01-06T00:00:00.000Z",
    status: "En validation",
    firstName: "Mohamed",
    lastName: "Taha",
    userName: "mtaha",
    registrationNumber: "2584",
}, {
    id: "987654321",
    createdDate: "2021-07-25T00:00:00.000Z",
    status: "Validé",
    firstName: "Hamid",
    lastName: "Orrich",
    userName: "horrich",
    registrationNumber: "1594",
}, {
    id: "852963741",
    createdDate: "2021-09-15T00:00:00.000Z",
    status: "Rejeté",
    firstName: "Rachid",
    lastName: "Mahidi",
    userName: "rmahidi",
    registrationNumber: "3576",
}];
var lastUserID;
var tableBody = document.getElementsByTagName('tbody')[0];

// Add user to users table, and refill the table of users
function showPage() {
    let slideBox = document.getElementsByClassName("slideBox")[0];
    if (slideBox.style.display != "none")
        slideBox.style.display = "none";
    else slideBox.style.display = "block";
}
// Delete user from users table, and refill the table of users
function deleteUser(id) {
    for (let index = 0; index < users.length; index++) {
        if (id == users[index].id) {
            users.pop(index);
            fillUsersTable();
        };
    }
}
// Add user to users table, and refill the table of users
function addUser() {
    let lastName = document.getElementsByName('lastName')[0].value;
    let firstName = document.getElementsByName('firstName')[0].value;
    let status = document.getElementsByName('status')[0].value;
    let userName = document.getElementsByName('userName')[0].value;
    let createdDate = document.getElementsByName('createdDate')[0].value;
    let registrationNumber = document.getElementsByName('registrationNumber')[0].value;
    lastUserID++;
    users.push({
        id: lastUserID,
        createdDate: createdDate,
        status: status,
        firstName: firstName,
        lastName: lastName,
        userName: userName,
        registrationNumber: registrationNumber,
    });
    fillUsersTable();
}
// Make sure date format contains the year in the last of string
function checkDateFormat(date) {
    let dateArray = ""
    if (date.includes('-')) dateArray = date.split('-');
    if (date.includes('/')) dateArray = date.split('/');
    if (dateArray[0].length >= 3 || dateArray[1].length >= 3) return dateArray.reverse().join('/');
    return dateArray.join('/');
}
// Fill users table
function fillUsersTable() {
    tableBody.innerHTML = "";
    // 'i' present increment index from 0 to number of users
    for (let i = 0; i < users.length; i++) {
        lastUserID = users[i].id;
        let id = users[i].id;
        let createdDate = users[i].createdDate;
        if (createdDate.includes("T")) createdDate = checkDateFormat(createdDate.split('T')[0]);
        else if (createdDate.includes(" ")) createdDate = checkDateFormat(createdDate.split(' ')[0]);
        else createdDate = checkDateFormat(createdDate);
        let status = users[i].status;
        let firstName = users[i].firstName;
        let lastName = users[i].lastName;
        let userName = users[i].userName;
        let registrationNumber = users[i].registrationNumber;
        // '<tr>' present table row
        // '<td>' present table data
        content = '<tr class="d-table-row align-middle">' +
            '<td class="d-table-cell">' + id + "</td>" +
            '<td class="d-table-cell">' + createdDate + "</td>";
        if (status == "En validation") content += '<td class="d-table-cell"><div class="on-validation badge w-100 p-2 my-2">' + status + "</div></td>";
        if (status == "Validé") content += '<td class="d-table-cell"><div class="valide badge w-100 p-2 my-2">' + status + "</div></td>";
        if (status == "Rejeté") content += '<td class="d-table-cell"><div class="rejected badge w-100 p-2 my-2">' + status + "</div></td>";
        content += '<td class="d-table-cell ">' + firstName + "</td>" +
            '<td class="d-table-cell">' + lastName + "</td>" +
            '<td class="d-table-cell">' + userName + "</td>" +
            '<td class="d-table-cell">' + registrationNumber + '</td>' +
            '<td class="d-table-cell text-center"><a href="#?" onclick="deleteUser(' +
            id + ')"><img class="icon" src = "icons/trash.svg" alt="Trash SVG"/></a></td>';
        "</tr>"
        tableBody.innerHTML += content;
    }
}
// Fill users table when page is loading/refreshing
fillUsersTable()